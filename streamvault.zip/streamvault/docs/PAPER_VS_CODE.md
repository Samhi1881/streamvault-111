# Paper → code mapping

| Paper | Code |
|---|---|
| Eq. 1 merchant aggregation | `streaming/transforms.py::merchant_aggregates` (`txn_count`, `total_amount`) |
| Eq. 2 `is_night = 1[hour<6 ∨ hour>22]` | `transforms.add_features` (Spark), `ml/features.py::is_night` (pandas) |
| Eq. 3 normalisation | `checkpointing/adaptive.py::normalize` (clipped to [0,1]) |
| Eq. 4 score `S` | `adaptive.py::checkpoint_score` |
| Eq. 5 `S ≥ θ` | `adaptive.py::should_checkpoint`, `policies.py::AdaptivePolicy` |
| Eq. 6 recovery ratio | `adaptive.py::recovery_ratio` (reported by the benchmark) |
| Eq. 7 snapshot metadata | `storage/versioning.py::SnapshotMeta` / `snapshot_metadata` |
| Eq. 8 merchant fraud rate | `merchant_aggregates` → `fraud_rate` |
| Eq. 9 feature vector | `ml/features.py::FEATURES` (amount, merchant category, card, time, velocity, payment type, night flag) |
| Eq. 10 sigmoid | `ml/risk.py::sigmoid` (XGBoost `predict_proba` applies it) |
| Eq. 11 risk tiers | `ml/risk.py::risk_tier` |
| Alg. 1 stream processing | `streaming/pipeline.py::process_batch` |
| Alg. 2 adaptive decision | `streaming/checkpoint_manager.py` + `AdaptivePolicy` |
| Alg. 3 Delta version management | Delta transaction log + `storage/versioning.py` |
| Alg. 4 risk classification | `ml/score.py` |
| Medallion layers | `config.py::LakePaths` (bronze / silver / gold, plus `dlq`, `alerts`) |
| Fault recovery (DLQ, replay, state) | `recovery/dlq.py`, `recovery/recover.py` |

## Where this differs from the paper

- The paper reports results from its own cluster runs. This repo ships the code to measure the same quantities; the numbers it
  prints are yours, not the paper's.
- Items the paper leaves unspecified (`t_max`, `d_max`, definition of "lineage depth" in a streaming job, memory source) are
  documented choices in `config.yaml` and the code.
- A "checkpoint" in the streaming job is a **recovery point** (Delta versions + Kafka offsets), layered on Spark's native
  checkpointing, not a replacement for it.
