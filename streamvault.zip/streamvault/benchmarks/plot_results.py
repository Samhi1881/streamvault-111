"""Plot recovery latency, throughput and checkpoint storage from results/benchmark.csv."""
import argparse
import csv
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

COLORS = {"eager": "#d1495b", "lazy": "#00798c", "adaptive": "#edae49"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="results/benchmark.csv")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()
    rows = list(csv.DictReader(open(args.csv)))
    sizes = sorted({int(r["rows"]) for r in rows})
    data = defaultdict(dict)
    for r in rows:
        data[r["strategy"]][int(r["rows"])] = r

    metrics = [("recovery_s", "Recovery latency (s)", "recovery_latency.png"),
               ("throughput_rps", "Throughput (records/s)", "throughput.png"),
               ("checkpoint_mb", "Checkpoint storage (MB)", "checkpoint_storage.png")]
    for key, label, fname in metrics:
        fig, ax = plt.subplots(figsize=(7, 4))
        width = 0.26
        for i, strat in enumerate(("eager", "lazy", "adaptive")):
            xs = [j + (i - 1) * width for j in range(len(sizes))]
            ys = [float(data[strat][s][key]) for s in sizes]
            bars = ax.bar(xs, ys, width, label=strat, color=COLORS[strat])
            ax.bar_label(bars, fmt="%.1f", fontsize=7)
        ax.set_xticks(range(len(sizes)))
        ax.set_xticklabels([f"{s//1000}K" for s in sizes])
        ax.set_xlabel("Dataset size (records)"); ax.set_ylabel(label)
        ax.legend(); ax.grid(axis="y", alpha=.3)
        fig.tight_layout(); fig.savefig(Path(args.out) / fname, dpi=150); plt.close(fig)
    print("plots written to", args.out)


if __name__ == "__main__":
    main()
