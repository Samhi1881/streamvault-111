"""Measure eager vs lazy vs adaptive checkpointing on a multi-stage Spark pipeline.

For every strategy the pipeline runs S stages over N rows. Each stage output is cached
(volatile). A *checkpoint* writes the stage output to Parquet and re-reads it (durable,
lineage truncated). A failure at the final stage is simulated by dropping every cache and
recomputing from the last durable checkpoint - that time is the recovery latency.

    python benchmarks/checkpoint_benchmark.py --sizes 100000 500000 1000000 --stages 12

Numbers depend on your machine; they will not match the paper's tables.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import tempfile
import time
from pathlib import Path

import psutil
from pyspark import StorageLevel
from pyspark.sql import functions as F

from streamvault.checkpointing import AdaptiveConfig, RuntimeMetrics, make_policy, recovery_ratio
from streamvault.streaming.spark_session import get_spark


def make_base(spark, n_rows: int, path: str) -> None:
    (spark.range(n_rows)
        .withColumn("key", (F.col("id") % 1000).cast("int"))
        .withColumn("x", F.rand(42))
        .withColumn("y", F.randn(7))
        .write.mode("overwrite").parquet(path))


def apply_stage(df, i: int):
    """Deterministic stage i: every third stage adds a shuffle (aggregate + join back)."""
    if i % 3 == 0:
        agg = df.groupBy("key").agg(F.avg("x").alias(f"avg_{i}"))
        return (df.join(agg, "key")
                  .withColumn("x", F.col("x") + F.col(f"avg_{i}") * 0.001)
                  .drop(f"avg_{i}"))
    return (df.withColumn("x", F.sin(F.col("x")) * 1.01 + F.lit(i * 0.001))
              .withColumn("y", F.col("y") * 0.99 + F.col("x")))


def dir_mb(path: str) -> float:
    total = sum(f.stat().st_size for f in Path(path).rglob("*") if f.is_file())
    return total / 1e6


def run_strategy(spark, name, cfg, base_path, n_rows, n_stages, work, d_max):
    policy = make_policy(name, AdaptiveConfig(**{**cfg.__dict__, "d_max": d_max}))
    ck_points = {0: base_path}           # stage -> durable path
    last_ck, n_ck, prev = 0, 0, None
    cur = spark.read.parquet(base_path)
    t_start = time.time()
    for i in range(1, n_stages + 1):
        t0 = time.time()
        cur = apply_stage(cur, i).persist(StorageLevel.MEMORY_AND_DISK)
        cur.count()                      # materialise stage output
        t_exec = time.time() - t0
        metrics = RuntimeMetrics(i - last_ck, t_exec, psutil.virtual_memory().percent)
        if policy.decide(metrics).checkpoint:
            path = f"{work}/{name}_{n_rows}/ck_{i}"
            cur.write.mode("overwrite").parquet(path)
            ck_points[i] = path
            last_ck, n_ck = i, n_ck + 1
            cur.unpersist()
            cur = spark.read.parquet(path)
        if prev is not None:
            prev.unpersist()
        prev = cur
    pipeline_s = time.time() - t_start

    # --- failure at the final stage: lose all volatile state, recompute from last checkpoint
    spark.catalog.clearCache()
    k_star = max(k for k in ck_points if k <= n_stages)
    t0 = time.time()
    r = spark.read.parquet(ck_points[k_star])
    for j in range(k_star + 1, n_stages + 1):
        r = apply_stage(r, j)
    r.write.format("noop").mode("overwrite").save()
    recovery_s = time.time() - t0

    ck_mb = sum(dir_mb(p) for k, p in ck_points.items() if k > 0)
    return {
        "strategy": name, "rows": n_rows, "stages": n_stages,
        "pipeline_s": round(pipeline_s, 3),
        "throughput_rps": round(n_rows / pipeline_s, 1),
        "checkpoints": n_ck, "checkpoint_mb": round(ck_mb, 2),
        "recovery_s": round(recovery_s, 3),
        "recovery_ratio": round(recovery_ratio(n_stages, k_star, n_stages), 3),
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--sizes", type=int, nargs="+", default=[100_000, 500_000, 1_000_000])
    ap.add_argument("--stages", type=int, default=12)
    ap.add_argument("--master", default="local[*]")
    ap.add_argument("--d-max", type=float, default=8)
    ap.add_argument("--repeats", type=int, default=1, help="median over N runs")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()

    spark = get_spark({"spark": {"master": args.master, "shuffle_partitions": 8}}, "StreamVault-bench", delta=False)
    work = tempfile.mkdtemp(prefix="sv_bench_")
    cfg = AdaptiveConfig()
    rows = []
    try:
        # warm-up so JIT / executor start-up does not pollute the first measurement
        wp = f"{work}/warm"; make_base(spark, 20_000, wp)
        run_strategy(spark, "lazy", cfg, wp, 20_000, 4, work, args.d_max)

        for n in args.sizes:
            base = f"{work}/base_{n}"
            make_base(spark, n, base)
            for name in ("eager", "lazy", "adaptive"):
                runs = [run_strategy(spark, name, cfg, base, n, args.stages, work, args.d_max)
                        for _ in range(args.repeats)]
                runs.sort(key=lambda r: r["recovery_s"])
                res = runs[len(runs) // 2]
                rows.append(res)
                print(res, flush=True)
    finally:
        spark.stop()
        shutil.rmtree(work, ignore_errors=True)

    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    (out / "benchmark.json").write_text(json.dumps(rows, indent=2))
    import csv
    with open(out / "benchmark.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(f"\nsaved {out}/benchmark.json and benchmark.csv  (cores={os.cpu_count()}, master={args.master})")


if __name__ == "__main__":
    main()
