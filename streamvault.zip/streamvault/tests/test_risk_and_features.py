import math

import pytest

from streamvault.data.synthetic import generate_transactions
from streamvault.ml.features import FEATURES, build_features, is_night
from streamvault.ml.risk import risk_tier, sigmoid
from streamvault.storage.versioning import schema_fingerprint


@pytest.mark.parametrize("p,tier", [
    (0.99, "Critical"), (0.851, "Critical"), (0.85, "High"), (0.61, "High"), (0.60, "Medium"),
    (0.36, "Medium"), (0.35, "Low"), (0.0, "Low"),
])
def test_risk_tier_boundaries(p, tier):
    assert risk_tier(p) == tier


def test_sigmoid():
    assert sigmoid(0) == 0.5
    assert sigmoid(800) == pytest.approx(1.0)
    assert sigmoid(-800) == pytest.approx(0.0)
    assert sigmoid(2) == pytest.approx(1 / (1 + math.exp(-2)))


@pytest.mark.parametrize("hour,expected", [(0, 1), (5, 1), (6, 0), (12, 0), (22, 0), (23, 1)])
def test_is_night(hour, expected):
    assert is_night(hour) == expected


def test_synthetic_data_shape_and_signal():
    df = generate_transactions(20_000, fraud_rate=0.05, seed=1)
    assert len(df) == 20_000 and df.transaction_id.is_unique
    assert 0.03 < df.is_fraud.mean() < 0.07
    assert (df.amount > 0).all()
    X = build_features(df)
    assert list(X.columns) == FEATURES
    night = X["is_night"].astype(bool)
    assert df.is_fraud[night].mean() > df.is_fraud[~night].mean()   # signal exists


def test_generator_is_deterministic():
    a = generate_transactions(500, seed=3)
    b = generate_transactions(500, seed=3)
    assert a.equals(b)


def test_schema_fingerprint_stable_and_sensitive():
    assert schema_fingerprint('{"a":1}') == schema_fingerprint('{"a":1}')
    assert schema_fingerprint('{"a":1}') != schema_fingerprint('{"a":2}')


def test_model_trains_above_chance():
    pytest.importorskip("xgboost")
    from streamvault.ml.train import train_model

    df = generate_transactions(30_000, fraud_rate=0.05, seed=5)
    _, metrics = train_model(df, seed=5)
    assert metrics["auc"] > 0.85
