"""Spark transform tests - run on plain local Spark, no Kafka or Delta needed."""
import json

from streamvault.streaming import transforms


def _raw(spark, rows):
    return spark.createDataFrame([(r,) for r in rows], ["raw"])


GOOD = {"transaction_id": "t1", "user_id": "u1", "timestamp": "2025-01-01T23:30:00",
        "amount": 10.5, "merchant_id": "m1", "merchant_category": "dining",
        "payment_type": "upi", "card_type": "debit", "is_fraud": 0}


def test_valid_and_invalid_split(spark):
    rows = [
        json.dumps(GOOD),
        json.dumps({**GOOD, "transaction_id": "t2", "amount": -5}),
        json.dumps({**GOOD, "transaction_id": None}),
        json.dumps({**GOOD, "transaction_id": "t4", "timestamp": "garbage"}),
        json.dumps(GOOD)[:-9],  # broken JSON
    ]
    valid, dlq = transforms.split_valid_invalid(transforms.parse_raw(_raw(spark, rows)))
    assert valid.count() == 1
    reasons = {r["reason"] for r in dlq.collect()}
    assert dlq.count() == 4
    assert reasons == {"malformed_json", "failed_validation"}


def test_silver_features_and_dedup(spark):
    rows = [json.dumps(GOOD), json.dumps(GOOD),
            json.dumps({**GOOD, "transaction_id": "t9", "timestamp": "2025-01-01T12:00:00"})]
    valid, _ = transforms.split_valid_invalid(transforms.parse_raw(_raw(spark, rows)))
    silver = {r["transaction_id"]: r for r in transforms.add_features(valid).collect()}
    assert len(silver) == 2                       # duplicate transaction_id dropped
    assert silver["t1"]["is_night"] == 1 and silver["t1"]["hour"] == 23
    assert silver["t9"]["is_night"] == 0


def test_merchant_aggregates(spark):
    rows = [json.dumps({**GOOD, "transaction_id": f"t{i}", "amount": 10.0, "is_fraud": int(i == 0)})
            for i in range(4)]
    valid, _ = transforms.split_valid_invalid(transforms.parse_raw(_raw(spark, rows)))
    gold = transforms.merchant_aggregates(transforms.add_features(valid)).collect()
    assert len(gold) == 1
    assert gold[0]["txn_count"] == 4
    assert gold[0]["total_amount"] == 40.0
    assert abs(gold[0]["fraud_rate"] - 0.25) < 1e-9
