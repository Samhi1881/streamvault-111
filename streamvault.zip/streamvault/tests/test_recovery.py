import json

from streamvault.checkpointing import AdaptiveConfig, AdaptivePolicy, EagerPolicy, LazyPolicy
from streamvault.recovery.recover import kafka_starting_offsets
from streamvault.streaming.checkpoint_manager import CheckpointManager


def test_kafka_offsets_json():
    s = kafka_starting_offsets("transactions", {"0": 10, "2": 7})
    assert json.loads(s) == {"transactions": {"0": 10, "2": 7}}
    assert kafka_starting_offsets("t", {}) is None


def test_manager_eager_writes_every_batch(tmp_path):
    mp = tmp_path / "m.jsonl"
    mgr = CheckpointManager(str(mp), EagerPolicy())
    for b in range(3):
        mgr.maybe_checkpoint(b, 0.1, lambda: {"versions": {"silver": 1}, "offsets": {"0": 5}})
    assert mgr.created == 3
    assert CheckpointManager.last_recovery_point(str(mp))["batch_id"] == 2


def test_manager_lazy_never_calls_capture(tmp_path):
    mgr = CheckpointManager(str(tmp_path / "m.jsonl"), LazyPolicy())

    def boom():
        raise AssertionError("capture must not run when no checkpoint is taken")

    for b in range(5):
        mgr.maybe_checkpoint(b, 0.1, boom)
    assert mgr.created == 0 and mgr.batches_since == 5
    assert CheckpointManager.last_recovery_point(str(tmp_path / "m.jsonl")) is None


def test_manager_adaptive_resets_lineage_after_checkpoint(tmp_path):
    mgr = CheckpointManager(str(tmp_path / "m.jsonl"), AdaptivePolicy(AdaptiveConfig(d_max=2, theta=0.3)))
    took = [mgr.maybe_checkpoint(b, 1.0, lambda: {"versions": {}, "offsets": {}})[0].checkpoint
            for b in range(6)]
    assert any(took)
    assert mgr.batches_since < 6      # lineage depth reset at least once
