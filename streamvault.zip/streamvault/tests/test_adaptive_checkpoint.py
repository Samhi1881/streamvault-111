import pytest

from streamvault.checkpointing import (
    AdaptiveConfig, AdaptivePolicy, EagerPolicy, LazyPolicy, RuntimeMetrics,
    checkpoint_score, make_policy, recovery_ratio, should_checkpoint,
)
from streamvault.checkpointing.adaptive import normalize


def test_default_weights_match_paper():
    c = AdaptiveConfig()
    assert (c.alpha, c.beta, c.gamma, c.theta) == (0.40, 0.35, 0.25, 0.65)
    assert abs(c.alpha + c.beta + c.gamma - 1.0) < 1e-12


def test_normalize_clips_to_unit_interval():
    l, t, m = normalize(RuntimeMetrics(20, 99, 150), d_max=10, t_max=50)
    assert (l, t, m) == (1.0, 1.0, 1.0)
    assert normalize(RuntimeMetrics(5, 25, 50), 10, 50) == (0.5, 0.5, 0.5)


def test_score_is_weighted_sum():
    m = RuntimeMetrics(lineage_depth=4, exec_time_s=10, memory_pct=60)
    s = checkpoint_score(m, AdaptiveConfig(d_max=8), t_max=20)
    assert s == pytest.approx(0.40 * 0.5 + 0.35 * 0.5 + 0.25 * 0.6)


def test_threshold_is_inclusive():
    cfg = AdaptiveConfig(alpha=1.0, beta=0.0, gamma=0.0, theta=0.5, d_max=10)
    ok, s = should_checkpoint(RuntimeMetrics(5, 0, 0), cfg, t_max=1)
    assert s == pytest.approx(0.5) and ok
    ok, _ = should_checkpoint(RuntimeMetrics(4, 0, 0), cfg, t_max=1)
    assert not ok


def test_recovery_ratio():
    assert recovery_ratio(10, 4, 12) == pytest.approx(0.5)
    assert recovery_ratio(5, 5, 12) == 0.0
    with pytest.raises(ValueError):
        recovery_ratio(3, 5, 12)
    with pytest.raises(ValueError):
        recovery_ratio(3, 1, 0)


def test_policies():
    m = RuntimeMetrics(1, 0.1, 10)
    assert EagerPolicy().decide(m).checkpoint
    assert not LazyPolicy().decide(m).checkpoint
    assert LazyPolicy(every=3).decide(RuntimeMetrics(3, 0.1, 10)).checkpoint
    assert not LazyPolicy(every=3).decide(RuntimeMetrics(2, 0.1, 10)).checkpoint


def test_adaptive_policy_deep_lineage_triggers_checkpoint():
    p = AdaptivePolicy(AdaptiveConfig(d_max=8))
    early = p.decide(RuntimeMetrics(1, 1.0, 30))     # shallow lineage -> skip
    late = p.decide(RuntimeMetrics(8, 1.0, 30))      # deep lineage, slow stage -> checkpoint
    assert not early.checkpoint
    assert late.checkpoint and late.score >= 0.65


def test_adaptive_uses_running_tmax():
    p = AdaptivePolicy(AdaptiveConfig(d_max=8))
    p.decide(RuntimeMetrics(1, 10.0, 0))
    d = p.decide(RuntimeMetrics(1, 5.0, 0))          # T = 5/10
    assert d.score == pytest.approx(0.40 * (1 / 8) + 0.35 * 0.5)


def test_make_policy_unknown():
    with pytest.raises(ValueError):
        make_policy("nope")
    assert make_policy("Adaptive").name == "adaptive"
