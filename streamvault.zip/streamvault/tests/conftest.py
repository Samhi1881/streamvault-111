import shutil

import pytest


@pytest.fixture(scope="session")
def spark():
    """Plain local Spark (no Delta jars needed for transform tests). Skipped without Java/PySpark."""
    pyspark = pytest.importorskip("pyspark")
    if shutil.which("java") is None:
        pytest.skip("Java not available")
    from pyspark.sql import SparkSession

    s = (SparkSession.builder.master("local[2]").appName("sv-tests")
         .config("spark.sql.shuffle.partitions", "2").config("spark.ui.enabled", "false").getOrCreate())
    yield s
    s.stop()
