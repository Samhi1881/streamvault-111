"""Synthetic financial transaction generator with learnable fraud signal.

The paper's HuggingFace dataset is a *categorisation* dataset; fraud labels are
not part of it, so fraud experiments here use synthetic labelled data.
Fraud rows skew towards night-time, large amounts and certain merchant categories.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from ..schema import CARD_TYPES, MERCHANT_CATEGORIES, PAYMENT_TYPES

_NIGHT_HOURS = np.array([0, 1, 2, 3, 4, 5, 23])


def generate_transactions(
    n: int, fraud_rate: float = 0.02, seed: int = 42, n_users: int = 5000,
    n_merchants: int = 500, start: str = "2025-01-01", days: int = 30,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    is_fraud = (rng.random(n) < fraud_rate).astype(int)
    fraud = is_fraud == 1

    day = rng.integers(0, days, n)
    hour = rng.integers(0, 24, n)
    night_pick = fraud & (rng.random(n) < 0.6)
    hour[night_pick] = rng.choice(_NIGHT_HOURS, night_pick.sum())
    seconds = rng.integers(0, 3600, n)
    ts = pd.Timestamp(start) + pd.to_timedelta(day * 86400 + hour * 3600 + seconds, unit="s")

    amount = np.where(fraud, rng.lognormal(5.0, 1.2, n), rng.lognormal(3.5, 1.0, n)).round(2)
    amount = np.maximum(amount, 0.5)

    merchant_idx = rng.integers(0, n_merchants, n)
    cat_legit = rng.choice(len(MERCHANT_CATEGORIES), n)
    # fraud tilts to electronics (1), travel (2), fashion (8)
    cat_fraud = rng.choice([1, 2, 8, 9], n, p=[0.4, 0.3, 0.2, 0.1])
    category = np.where(fraud, cat_fraud, cat_legit)

    pay_legit = rng.choice(len(PAYMENT_TYPES), n, p=[0.40, 0.25, 0.20, 0.10, 0.05])
    pay_fraud = rng.choice(len(PAYMENT_TYPES), n, p=[0.10, 0.55, 0.20, 0.05, 0.10])
    pay = np.where(fraud, pay_fraud, pay_legit)

    return pd.DataFrame({
        "transaction_id": [f"txn_{i:010d}" for i in range(n)],
        "user_id": [f"user_{u:05d}" for u in rng.integers(0, n_users, n)],
        "timestamp": ts.strftime("%Y-%m-%dT%H:%M:%S"),
        "amount": amount,
        "merchant_id": [f"m_{m:04d}" for m in merchant_idx],
        "merchant_category": [MERCHANT_CATEGORIES[c] for c in category],
        "payment_type": [PAYMENT_TYPES[p] for p in pay],
        "card_type": rng.choice(CARD_TYPES, n),
        "is_fraud": is_fraud,
    })


def main():
    ap = argparse.ArgumentParser(description="Generate synthetic transactions")
    ap.add_argument("--n", type=int, default=100_000)
    ap.add_argument("--fraud-rate", type=float, default=0.02)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="data/raw/transactions.jsonl")
    args = ap.parse_args()
    df = generate_transactions(args.n, args.fraud_rate, args.seed)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.suffix == ".parquet":
        df.to_parquet(out, index=False)
    elif out.suffix == ".csv":
        df.to_csv(out, index=False)
    else:
        df.to_json(out, orient="records", lines=True)
    print(f"wrote {len(df):,} rows (fraud={df.is_fraud.mean():.2%}) -> {out}")


if __name__ == "__main__":
    main()
