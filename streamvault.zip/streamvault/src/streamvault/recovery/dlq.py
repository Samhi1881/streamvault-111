"""Dead-letter-queue replay: re-validate DLQ records and promote the ones that now pass.

    python -m streamvault.recovery.dlq
"""
from __future__ import annotations

import argparse

from ..config import lake_paths, load_config
from ..streaming import transforms
from ..streaming.spark_session import get_spark


def replay_dlq(spark, cfg) -> int:
    from delta.tables import DeltaTable

    paths = lake_paths(cfg)
    if not DeltaTable.isDeltaTable(spark, paths.dlq):
        return 0
    dlq = spark.read.format("delta").load(paths.dlq).select("raw").distinct()
    parsed = transforms.parse_raw(dlq)
    valid, _ = transforms.split_valid_invalid(parsed)
    silver = transforms.add_features(valid)
    promoted_raw = parsed.join(valid.select("transaction_id"), parsed["j.transaction_id"] == valid["transaction_id"]) \
        .select("raw").distinct()
    n = silver.count()
    if n:
        silver.write.format("delta").mode("append").save(paths.silver)
        (DeltaTable.forPath(spark, paths.dlq).alias("d")
            .merge(promoted_raw.alias("p"), "d.raw = p.raw")
            .whenMatchedDelete().execute())
    return n


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default="config/config.yaml")
    args = ap.parse_args()
    cfg = load_config(args.config)
    spark = get_spark(cfg, "StreamVault-dlq-replay")
    print(f"replayed {replay_dlq(spark, cfg)} records from the DLQ into Silver")


if __name__ == "__main__":
    main()
