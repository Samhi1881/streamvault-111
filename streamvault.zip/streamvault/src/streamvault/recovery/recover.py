"""Restore the lake to the last recovery point (Delta RESTORE) and compute Kafka replay offsets."""
from __future__ import annotations

import json
import logging
from typing import Optional

from ..config import lake_paths
from ..streaming.checkpoint_manager import CheckpointManager

log = logging.getLogger(__name__)


def kafka_starting_offsets(topic: str, offsets: dict) -> Optional[str]:
    """Build Spark's ``startingOffsets`` JSON: {"topic": {"0": 123, "1": 98}}."""
    if not offsets:
        return None
    return json.dumps({topic: {str(p): int(o) for p, o in offsets.items()}})


def restore_last_recovery_point(spark, cfg) -> Optional[dict]:
    from delta.tables import DeltaTable

    point = CheckpointManager.last_recovery_point(cfg["lake"]["manifest_path"])
    if point is None:
        return None
    paths = lake_paths(cfg)
    for name, version in point["versions"].items():
        path = paths.table(name)
        if DeltaTable.isDeltaTable(spark, path):
            DeltaTable.forPath(spark, path).restoreToVersion(int(version))
            log.info("restored %s -> version %s", name, version)
    return point
