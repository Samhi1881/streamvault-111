"""Delta Lake snapshot metadata, time travel and rollback (paper Eq. 7, Algorithm 3).

    python -m streamvault.storage.versioning --table silver
    python -m streamvault.storage.versioning --table silver --rollback 3
"""
from __future__ import annotations

import argparse
import hashlib
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class SnapshotMeta:
    """v_n = (version_id, timestamp, |D_n|, H_schema)."""

    version_id: int
    timestamp: str
    num_records: int
    schema_hash: str


def schema_fingerprint(schema_json: str) -> str:
    """H_schema: short SHA-256 of the schema JSON."""
    return hashlib.sha256(schema_json.encode("utf-8")).hexdigest()[:16]


def snapshot_metadata(spark, path: str, version: int | None = None) -> SnapshotMeta:
    from delta.tables import DeltaTable

    history = DeltaTable.forPath(spark, path).history()
    row = (
        history.filter(f"version = {version}") if version is not None
        else history.orderBy(history.version.desc()).limit(1)
    ).select("version", "timestamp").first()
    if row is None:
        raise ValueError(f"version {version} not found for {path}")
    df = read_version(spark, path, row["version"])
    return SnapshotMeta(int(row["version"]), str(row["timestamp"]), df.count(), schema_fingerprint(df.schema.json()))


def list_versions(spark, path: str):
    from delta.tables import DeltaTable

    return DeltaTable.forPath(spark, path).history().select("version", "timestamp", "operation").orderBy("version")


def read_version(spark, path: str, version: int):
    """Time-travel read."""
    return spark.read.format("delta").option("versionAsOf", int(version)).load(path)


def rollback(spark, path: str, version: int) -> None:
    """Restore the table in place to an earlier version (history is preserved)."""
    from delta.tables import DeltaTable

    DeltaTable.forPath(spark, path).restoreToVersion(int(version))


def main():
    from ..config import lake_paths, load_config
    from ..streaming.spark_session import get_spark

    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default="config/config.yaml")
    ap.add_argument("--table", default="silver", choices=["bronze", "silver", "gold", "dlq", "alerts"])
    ap.add_argument("--rollback", type=int, default=None, help="restore table to this version")
    args = ap.parse_args()
    cfg = load_config(args.config)
    path = lake_paths(cfg).table(args.table)
    spark = get_spark(cfg, "StreamVault-versions")
    if args.rollback is not None:
        rollback(spark, path, args.rollback)
        print(f"restored {args.table} to version {args.rollback}")
    list_versions(spark, path).show(50, truncate=False)
    print(snapshot_metadata(spark, path))


if __name__ == "__main__":
    main()
