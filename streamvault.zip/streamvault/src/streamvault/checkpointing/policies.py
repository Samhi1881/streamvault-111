"""Checkpoint policies compared in the paper: eager, lazy and adaptive."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .adaptive import AdaptiveConfig, RuntimeMetrics, should_checkpoint


@dataclass(frozen=True)
class Decision:
    checkpoint: bool
    score: float


class EagerPolicy:
    """Checkpoint after every stage: fastest recovery, highest overhead."""

    name = "eager"

    def decide(self, m: RuntimeMetrics) -> Decision:
        return Decision(True, 1.0)


class LazyPolicy:
    """Checkpoint rarely. ``every=None`` never checkpoints (lineage recompute only)."""

    name = "lazy"

    def __init__(self, every: Optional[int] = None):
        self.every = every

    def decide(self, m: RuntimeMetrics) -> Decision:
        if self.every and m.lineage_depth >= self.every:
            return Decision(True, 1.0)
        return Decision(False, 0.0)


class AdaptivePolicy:
    """Checkpoint when S = a*L + b*T + g*M >= theta (paper Eq. 3-5).

    The paper does not specify t_max; unless ``cfg.t_max`` is set we use the
    running maximum of the execution times seen so far.
    """

    name = "adaptive"

    def __init__(self, cfg: Optional[AdaptiveConfig] = None):
        self.cfg = cfg or AdaptiveConfig()
        self._t_seen = 0.0

    def decide(self, m: RuntimeMetrics) -> Decision:
        self._t_seen = max(self._t_seen, m.exec_time_s)
        t_max = self.cfg.t_max or self._t_seen
        ok, score = should_checkpoint(m, self.cfg, t_max)
        return Decision(ok, score)


def make_policy(name: str, cfg: Optional[AdaptiveConfig] = None, lazy_every: Optional[int] = None):
    name = name.lower()
    if name == "eager":
        return EagerPolicy()
    if name == "lazy":
        return LazyPolicy(lazy_every)
    if name == "adaptive":
        return AdaptivePolicy(cfg)
    raise ValueError(f"unknown checkpoint policy: {name}")
