"""Adaptive checkpoint decision (paper Eq. 3-6). Pure Python, no Spark needed."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class AdaptiveConfig:
    alpha: float = 0.40   # lineage-depth weight
    beta: float = 0.35    # execution-time weight
    gamma: float = 0.25   # memory weight
    theta: float = 0.65   # threshold
    d_max: float = 8.0    # lineage depth mapped to 1.0
    t_max: Optional[float] = None  # None => caller supplies a running maximum

    @classmethod
    def from_dict(cls, d: dict) -> "AdaptiveConfig":
        return cls(
            alpha=d.get("alpha", 0.40), beta=d.get("beta", 0.35), gamma=d.get("gamma", 0.25),
            theta=d.get("theta", 0.65), d_max=d.get("d_max", 8), t_max=d.get("t_max"),
        )


@dataclass(frozen=True)
class RuntimeMetrics:
    lineage_depth: float   # d: stages/micro-batches since the last checkpoint
    exec_time_s: float     # t_exec: execution time of the current stage/batch
    memory_pct: float      # m: memory utilisation in percent (0-100)


def _clip01(x: float) -> float:
    return max(0.0, min(1.0, x))


def normalize(m: RuntimeMetrics, d_max: float, t_max: float):
    """Eq. 3: L = d/d_max, T = t_exec/t_max, M = m/100 (each clipped to [0, 1])."""
    l_norm = _clip01(m.lineage_depth / d_max) if d_max > 0 else 0.0
    t_norm = _clip01(m.exec_time_s / t_max) if t_max and t_max > 0 else 0.0
    m_norm = _clip01(m.memory_pct / 100.0)
    return l_norm, t_norm, m_norm


def checkpoint_score(m: RuntimeMetrics, cfg: AdaptiveConfig, t_max: float) -> float:
    """Eq. 4: S = alpha*L + beta*T + gamma*M."""
    l, t, mem = normalize(m, cfg.d_max, t_max)
    return cfg.alpha * l + cfg.beta * t + cfg.gamma * mem


def should_checkpoint(m: RuntimeMetrics, cfg: AdaptiveConfig, t_max: float):
    """Eq. 5: checkpoint iff S >= theta. Returns (decision, score)."""
    s = checkpoint_score(m, cfg, t_max)
    return s >= cfg.theta, s


def recovery_ratio(k: int, k_star: int, n_stages: int) -> float:
    """Eq. 6: r = (k - k*) / N, the fraction of the pipeline recomputed after a failure."""
    if n_stages <= 0:
        raise ValueError("n_stages must be positive")
    if k_star > k:
        raise ValueError("last checkpoint stage cannot be after the failure stage")
    return (k - k_star) / n_stages
