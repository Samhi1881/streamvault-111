"""Pure DataFrame transforms for the Bronze -> Silver -> Gold flow (testable without Kafka)."""
from __future__ import annotations

from pyspark.sql import DataFrame, functions as F

from ..schema import spark_schema


def parse_raw(df: DataFrame) -> DataFrame:
    """Parse the ``raw`` JSON string column into a ``j`` struct."""
    return df.withColumn("j", F.from_json(F.col("raw"), spark_schema()))


def _is_valid():
    j = F.col("j")
    cond = (
        j["transaction_id"].isNotNull()
        & j["user_id"].isNotNull()
        & j["merchant_id"].isNotNull()
        & (j["amount"] > 0)
        & F.to_timestamp(j["timestamp"]).isNotNull()
    )
    return F.coalesce(cond, F.lit(False))


def split_valid_invalid(parsed: DataFrame):
    """Return (valid_rows, dlq_rows). Invalid rows keep the raw payload plus a reason."""
    valid_flag = _is_valid()
    valid = parsed.filter(valid_flag).select("j.*")
    # from_json (PERMISSIVE) yields a struct of nulls for unparseable JSON, not a null struct
    j = F.col("j")
    all_null = (
        j.isNull()
        | (j["user_id"].isNull() & j["amount"].isNull() & j["merchant_id"].isNull() & j["timestamp"].isNull())
    )
    reason = F.when(all_null, F.lit("malformed_json")).otherwise(F.lit("failed_validation"))
    cols = [c for c in ("partition", "offset") if c in parsed.columns]
    dlq = (
        parsed.filter(~valid_flag)
        .select("raw", reason.alias("reason"), *cols)
        .withColumn("dlq_ts", F.current_timestamp())
    )
    return valid, dlq


def add_features(valid: DataFrame) -> DataFrame:
    """Silver layer: de-duplicate, parse event time, add hour + night indicator (Eq. 2)."""
    return (
        valid.dropDuplicates(["transaction_id"])
        .withColumn("event_time", F.to_timestamp("timestamp"))
        .withColumn("hour", F.hour("event_time"))
        .withColumn("is_night", F.when((F.col("hour") < 6) | (F.col("hour") > 22), 1).otherwise(0))
        .withColumn("ingested_at", F.current_timestamp())
    )


def merchant_aggregates(silver: DataFrame, window: str = "5 minutes") -> DataFrame:
    """Gold layer: per-merchant, per event-time window count + total (Eq. 1) and fraud rate (Eq. 8)."""
    return (
        silver.groupBy("merchant_id", F.window("event_time", window).alias("w"))
        .agg(
            F.count("*").alias("txn_count"),
            F.round(F.sum("amount"), 2).alias("total_amount"),
            F.avg(F.col("is_fraud").cast("double")).alias("fraud_rate"),
        )
        .select(
            "merchant_id",
            F.col("w.start").alias("window_start"),
            F.col("w.end").alias("window_end"),
            "txn_count", "total_amount", "fraud_rate",
        )
    )
