"""Recovery-point manager driven by a checkpoint policy.

Spark's own ``checkpointLocation`` (offset log) keeps running for exactly-once sinks.
On top of that, a *recovery point* is a durable record of
(batch_id, Delta version of every table, cumulative Kafka offsets). The adaptive
policy decides when it is worth paying for one. After a failure, recovery restores
each table to its recorded version and replays Kafka from the recorded offsets.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Callable, Dict, Optional

import psutil

from ..checkpointing import Decision, RuntimeMetrics


class CheckpointManager:
    def __init__(self, manifest_path: str, policy):
        self.manifest = Path(manifest_path)
        self.manifest.parent.mkdir(parents=True, exist_ok=True)
        self.policy = policy
        self.batches_since = 0
        self.created = 0

    def maybe_checkpoint(
        self, batch_id: int, batch_seconds: float,
        capture: Callable[[], Dict],
    ):
        """Evaluate the policy; if it says so, call ``capture()`` and persist the recovery point.

        ``capture`` is only invoked when a checkpoint is created, so skipped
        checkpoints cost nothing.  Returns (Decision, lineage_depth_used).
        """
        self.batches_since += 1
        depth = self.batches_since
        metrics = RuntimeMetrics(depth, batch_seconds, psutil.virtual_memory().percent)
        decision: Decision = self.policy.decide(metrics)
        if decision.checkpoint:
            state = capture()
            record = {"batch_id": batch_id, "ts": time.time(), "score": decision.score,
                      "lineage_depth": depth, **state}
            with open(self.manifest, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(record) + "\n")
            self.batches_since = 0
            self.created += 1
        return decision, depth

    @staticmethod
    def last_recovery_point(manifest_path: str) -> Optional[dict]:
        p = Path(manifest_path)
        if not p.exists():
            return None
        lines = [ln for ln in p.read_text().splitlines() if ln.strip()]
        return json.loads(lines[-1]) if lines else None
