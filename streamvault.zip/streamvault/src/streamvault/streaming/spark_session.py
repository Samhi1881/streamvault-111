"""SparkSession factory with Delta Lake (and optional Kafka / MinIO-S3A) support."""
from __future__ import annotations

SPARK_VERSION = "3.5.0"
KAFKA_PKG = f"org.apache.spark:spark-sql-kafka-0-10_2.12:{SPARK_VERSION}"
HADOOP_AWS_PKG = "org.apache.hadoop:hadoop-aws:3.3.4"


def get_spark(cfg: dict | None = None, app_name: str = "StreamVault", kafka: bool = False, delta: bool = True):
    from pyspark.sql import SparkSession

    if delta:
        from delta import configure_spark_with_delta_pip

    cfg = cfg or {}
    spark_cfg = cfg.get("spark", {})
    builder = (
        SparkSession.builder.appName(app_name)
        .master(spark_cfg.get("master", "local[*]"))
        .config("spark.sql.shuffle.partitions", str(spark_cfg.get("shuffle_partitions", 8)))
        .config("spark.ui.showConsoleProgress", "false")
    )
    packages = []
    if kafka:
        packages.append(KAFKA_PKG)

    s3 = cfg.get("storage", {}).get("s3", {})
    if s3.get("enabled"):
        packages.append(HADOOP_AWS_PKG)
        builder = (
            builder.config("spark.hadoop.fs.s3a.endpoint", s3["endpoint"])
            .config("spark.hadoop.fs.s3a.access.key", s3["access_key"])
            .config("spark.hadoop.fs.s3a.secret.key", s3["secret_key"])
            .config("spark.hadoop.fs.s3a.path.style.access", "true")
            .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        )
    if delta:
        builder = (
            builder.config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
            .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        )
        spark = configure_spark_with_delta_pip(builder, extra_packages=packages).getOrCreate()
    else:  # plain Spark (used by the checkpoint benchmark, which needs no Delta jars)
        if packages:
            builder = builder.config("spark.jars.packages", ",".join(packages))
        spark = builder.getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    return spark
