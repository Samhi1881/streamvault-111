"""Spark Structured Streaming pipeline: Kafka (or JSONL files) -> Bronze/Silver/Gold Delta tables.

    python -m streamvault.streaming.pipeline --source kafka
    python -m streamvault.streaming.pipeline --source files --input-dir data/stream_in
    python -m streamvault.streaming.pipeline --source kafka --recover      # restore last recovery point
    python -m streamvault.streaming.pipeline --policy eager|lazy|adaptive  # compare strategies
"""
from __future__ import annotations

import argparse
import logging
import shutil
import time

from pyspark.sql import functions as F

from ..checkpointing import AdaptiveConfig, make_policy
from ..config import lake_paths, load_config
from ..monitoring import Metrics
from ..recovery.recover import kafka_starting_offsets, restore_last_recovery_point
from . import transforms
from .checkpoint_manager import CheckpointManager
from .spark_session import get_spark

log = logging.getLogger("streamvault.pipeline")


def _delta_version(spark, path: str) -> int:
    from delta.tables import DeltaTable

    return int(DeltaTable.forPath(spark, path).history(1).select("version").first()[0])


def _read_source(spark, cfg, source, input_dir, starting_offsets):
    if source == "kafka":
        reader = (
            spark.readStream.format("kafka")
            .option("kafka.bootstrap.servers", cfg["kafka"]["bootstrap_servers"])
            .option("subscribe", cfg["kafka"]["topic"])
            .option("startingOffsets", starting_offsets or "earliest")
            .option("maxOffsetsPerTrigger", cfg["streaming"]["max_offsets_per_trigger"])
            .option("failOnDataLoss", "false")
        )
        return reader.load().select(
            F.col("key").cast("string").alias("key"),
            F.col("value").cast("string").alias("raw"),
            F.col("partition").cast("int").alias("partition"),
            F.col("offset").cast("long").alias("offset"),
            F.col("timestamp").alias("source_ts"),
        )
    return (
        spark.readStream.format("text").option("maxFilesPerTrigger", 2).load(input_dir)
        .select(
            F.lit(None).cast("string").alias("key"),
            F.col("value").alias("raw"),
            F.lit(None).cast("int").alias("partition"),
            F.lit(None).cast("long").alias("offset"),
            F.current_timestamp().alias("source_ts"),
        )
    )


def run(cfg, source="kafka", input_dir="data/stream_in", policy_name="adaptive",
        recover=False, await_termination=True, run_seconds=None):
    paths = lake_paths(cfg)
    spark = get_spark(cfg, "StreamVault", kafka=(source == "kafka"))
    metrics = Metrics(cfg["monitoring"].get("prometheus_port"))
    policy = make_policy(policy_name, AdaptiveConfig.from_dict(cfg["adaptive_checkpoint"]))
    manager = CheckpointManager(cfg["lake"]["manifest_path"], policy)

    starting_offsets = None
    if recover:
        point = restore_last_recovery_point(spark, cfg)
        if point:
            starting_offsets = kafka_starting_offsets(cfg["kafka"]["topic"], point.get("offsets", {}))
            # drop Spark's own offset log so the stored offsets take effect
            shutil.rmtree(cfg["lake"]["spark_checkpoint_dir"], ignore_errors=True)
            log.warning("Recovered to batch %s; replaying from %s", point["batch_id"], starting_offsets)
        else:
            log.warning("No recovery point found; starting from scratch")

    def process_batch(batch_df, batch_id):
        t0 = time.time()
        batch_df = batch_df.persist()
        n_rows = batch_df.count()
        if n_rows == 0:
            batch_df.unpersist()
            return

        # Bronze: raw, append-only
        batch_df.write.format("delta").mode("append").save(paths.bronze)

        # Silver / DLQ: validate, split, enrich
        parsed = transforms.parse_raw(batch_df).persist()
        valid, dlq = transforms.split_valid_invalid(parsed)
        n_dlq = dlq.count()
        if n_dlq:
            dlq.write.format("delta").mode("append").save(paths.dlq)
        silver = transforms.add_features(valid).persist()
        silver.write.format("delta").mode("append").save(paths.silver)

        # Gold: merchant-window aggregates
        transforms.merchant_aggregates(silver, cfg["streaming"]["window"]).write \
            .format("delta").mode("append").save(paths.gold)
        parsed.unpersist(); silver.unpersist(); batch_df.unpersist()

        elapsed = time.time() - t0

        def capture():
            versions = {n: _delta_version(spark, paths.table(n)) for n in ("bronze", "silver", "gold")}
            if n_dlq or _exists(spark, paths.dlq):
                versions["dlq"] = _delta_version(spark, paths.dlq)
            return {"versions": versions, "offsets": _bronze_offsets(spark, paths.bronze)}

        decision, depth = manager.maybe_checkpoint(batch_id, elapsed, capture)
        metrics.observe_batch(elapsed, n_rows, decision.score, depth, decision.checkpoint, n_dlq)
        log.info("batch=%s rows=%s dlq=%s time=%.2fs S=%.3f depth=%s checkpoint=%s",
                 batch_id, n_rows, n_dlq, elapsed, decision.score, depth, decision.checkpoint)

    query = (
        _read_source(spark, cfg, source, input_dir, starting_offsets)
        .writeStream.foreachBatch(process_batch)
        .option("checkpointLocation", cfg["lake"]["spark_checkpoint_dir"])
        .trigger(processingTime=f"{cfg['streaming']['trigger_seconds']} seconds")
        .start()
    )
    if run_seconds:
        query.awaitTermination(run_seconds)
        query.stop()
    elif await_termination:
        query.awaitTermination()
    return query, manager


def _exists(spark, path: str) -> bool:
    from delta.tables import DeltaTable

    return DeltaTable.isDeltaTable(spark, path)


def _bronze_offsets(spark, bronze_path: str) -> dict:
    """Next Kafka offset per partition, derived from the Bronze table itself so it is
    always consistent with the Bronze version recorded in the same recovery point."""
    rows = (
        spark.read.format("delta").load(bronze_path)
        .filter(F.col("partition").isNotNull())
        .groupBy("partition").agg(F.max("offset").alias("max_offset")).collect()
    )
    return {str(r["partition"]): int(r["max_offset"]) + 1 for r in rows}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default="config/config.yaml")
    ap.add_argument("--source", choices=["kafka", "files"], default="kafka")
    ap.add_argument("--input-dir", default="data/stream_in")
    ap.add_argument("--policy", choices=["eager", "lazy", "adaptive"], default="adaptive")
    ap.add_argument("--recover", action="store_true")
    ap.add_argument("--run-seconds", type=int, default=None, help="stop after N seconds")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    run(load_config(args.config), args.source, args.input_dir, args.policy, args.recover,
        run_seconds=args.run_seconds)


if __name__ == "__main__":
    main()
