"""Score Silver transactions with the trained XGBoost model and write risk-tiered alerts.

    python -m streamvault.ml.score --model models/xgb_fraud.json
"""
from __future__ import annotations

import argparse

import pandas as pd

from ..config import lake_paths, load_config
from .features import build_features
from .risk import risk_tier


def score_frame(model, df: pd.DataFrame) -> pd.DataFrame:
    proba = model.predict_proba(build_features(df))[:, 1]  # sigmoid of raw margin (Eq. 10)
    out = df[["transaction_id", "user_id", "merchant_id", "amount"]].copy()
    out["fraud_probability"] = proba
    out["risk_tier"] = [risk_tier(p) for p in proba]
    return out


def main():
    from xgboost import XGBClassifier

    from ..streaming.spark_session import get_spark

    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default="config/config.yaml")
    ap.add_argument("--model", default="models/xgb_fraud.json")
    ap.add_argument("--min-tier", default="Medium", choices=["Low", "Medium", "High", "Critical"])
    args = ap.parse_args()
    cfg = load_config(args.config)
    paths = lake_paths(cfg)
    spark = get_spark(cfg, "StreamVault-scoring")

    model = XGBClassifier()
    model.load_model(args.model)
    silver = spark.read.format("delta").load(paths.silver).toPandas()
    scored = score_frame(model, silver)
    order = ["Low", "Medium", "High", "Critical"]
    alerts = scored[scored["risk_tier"].map(order.index) >= order.index(args.min_tier)]
    spark.createDataFrame(alerts).write.format("delta").mode("overwrite").save(paths.alerts)
    print(scored["risk_tier"].value_counts().to_string())
    print(f"wrote {len(alerts):,} alerts (>= {args.min_tier}) to {paths.alerts}")


if __name__ == "__main__":
    main()
