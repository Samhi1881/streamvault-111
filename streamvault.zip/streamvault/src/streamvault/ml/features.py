"""Pandas feature engineering used for both training and scoring.

Mirrors the Spark-side features (hour, is_night) so train/serve stay consistent.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..schema import CARD_TYPES, MERCHANT_CATEGORIES, PAYMENT_TYPES

FEATURES = [
    "amount_log", "hour", "is_night", "user_txn_count_1h",
    "merchant_cat_code", "payment_type_code", "card_type_code",
]


def is_night(hour: int) -> int:
    """Eq. 2: is_night = 1[hour < 6 or hour > 22]."""
    return int(hour < 6 or hour > 22)


def _codes(series: pd.Series, vocab: list) -> np.ndarray:
    return pd.Categorical(series, categories=vocab).codes.astype("int8")


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    ts = pd.to_datetime(df["timestamp"])
    hour = ts.dt.hour
    out = pd.DataFrame(index=df.index)
    out["amount_log"] = np.log1p(df["amount"].astype(float))
    out["hour"] = hour.astype("int8")
    out["is_night"] = ((hour < 6) | (hour > 22)).astype("int8")
    # velocity indicator: transactions by the same user within the same clock hour
    bucket = ts.dt.floor("h")
    out["user_txn_count_1h"] = (
        df.groupby([df["user_id"], bucket])["transaction_id"].transform("size").astype("int32")
    )
    out["merchant_cat_code"] = _codes(df["merchant_category"], MERCHANT_CATEGORIES)
    out["payment_type_code"] = _codes(df["payment_type"], PAYMENT_TYPES)
    out["card_type_code"] = _codes(df["card_type"], CARD_TYPES)
    return out[FEATURES]
