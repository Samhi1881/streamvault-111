"""Train and evaluate the XGBoost fraud classifier.

    python -m streamvault.ml.train --n 200000 --out models/
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import classification_report, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split

from ..data.synthetic import generate_transactions
from .features import FEATURES, build_features


def _best_threshold(y_true, proba) -> float:
    """Pick the probability cut-off that maximises fraud-class F1 on a validation split."""
    from sklearn.metrics import precision_recall_curve

    prec, rec, thr = precision_recall_curve(y_true, proba)
    f1 = 2 * prec[:-1] * rec[:-1] / np.maximum(prec[:-1] + rec[:-1], 1e-12)
    return float(thr[int(np.argmax(f1))]) if len(thr) else 0.5


def train_model(df, seed: int = 42):
    from xgboost import XGBClassifier

    X = build_features(df)
    y = df["is_fraud"].astype(int).values
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=seed)
    X_fit, X_val, y_fit, y_val = train_test_split(X_tr, y_tr, test_size=0.2, stratify=y_tr, random_state=seed)
    model = XGBClassifier(
        n_estimators=300, max_depth=6, learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
        eval_metric="logloss", random_state=seed, n_jobs=-1, tree_method="hist",
    )
    model.fit(X_fit, y_fit)
    threshold = _best_threshold(y_val, model.predict_proba(X_val)[:, 1])
    proba = model.predict_proba(X_te)[:, 1]
    pred = (proba >= threshold).astype(int)
    report = classification_report(
        y_te, pred, target_names=["legitimate", "fraudulent"], output_dict=True, digits=4
    )
    metrics = {
        "auc": float(roc_auc_score(y_te, proba)),
        "weighted_f1": float(f1_score(y_te, pred, average="weighted")),
        "decision_threshold": threshold,
        "fraud_prevalence_test": float(np.mean(y_te)),
        "report": report,
        "features": FEATURES,
    }
    return model, metrics


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--n", type=int, default=200_000, help="synthetic rows to generate")
    ap.add_argument("--fraud-rate", type=float, default=0.02)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="models")
    args = ap.parse_args()

    df = generate_transactions(args.n, fraud_rate=args.fraud_rate, seed=args.seed)
    model, metrics = train_model(df, seed=args.seed)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    model.save_model(str(out / "xgb_fraud.json"))
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2))
    f = metrics["report"]["fraudulent"]
    print(f"AUC={metrics['auc']:.4f}  weighted-F1={metrics['weighted_f1']:.4f}  threshold={metrics['decision_threshold']:.3f}")
    print(f"fraud class: precision={f['precision']:.3f} recall={f['recall']:.3f} f1={f['f1-score']:.3f}")
    print(f"saved model + metrics to {out}/")


if __name__ == "__main__":
    main()
