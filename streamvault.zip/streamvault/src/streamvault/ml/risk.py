"""Fraud probability and risk tiers (paper Eq. 10-11)."""
from __future__ import annotations

import math


def sigmoid(raw_score: float) -> float:
    """Eq. 10: p = 1 / (1 + exp(-y_hat)). Numerically stable."""
    if raw_score >= 0:
        return 1.0 / (1.0 + math.exp(-raw_score))
    z = math.exp(raw_score)
    return z / (1.0 + z)


def risk_tier(p: float) -> str:
    """Eq. 11: Critical > 0.85, High (0.60, 0.85], Medium (0.35, 0.60], Low <= 0.35."""
    if p > 0.85:
        return "Critical"
    if p > 0.60:
        return "High"
    if p > 0.35:
        return "Medium"
    return "Low"
