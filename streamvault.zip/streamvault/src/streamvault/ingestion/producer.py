"""Publish synthetic transactions to Kafka (partition key = user_id).

    python -m streamvault.ingestion.producer --n 50000 --rate 2000 --bad-rate 0.01

``--bad-rate`` injects malformed / invalid records to exercise the dead-letter queue.
Use ``--to-dir data/stream_in`` to write JSONL files instead (no Kafka needed).
"""
from __future__ import annotations

import argparse
import json
import random
import time
from pathlib import Path

from ..config import load_config
from ..data.synthetic import generate_transactions


def _corrupt(rec: dict, rng: random.Random) -> str:
    kind = rng.choice(["broken_json", "negative_amount", "missing_id", "bad_timestamp"])
    if kind == "broken_json":
        return json.dumps(rec)[:-7]
    if kind == "negative_amount":
        rec["amount"] = -abs(rec["amount"])
    elif kind == "missing_id":
        rec["transaction_id"] = None
    else:
        rec["timestamp"] = "not-a-time"
    return json.dumps(rec)


def _records(n, fraud_rate, seed, bad_rate):
    rng = random.Random(seed)
    df = generate_transactions(n, fraud_rate=fraud_rate, seed=seed)
    for rec in df.to_dict(orient="records"):
        key = rec["user_id"]
        value = _corrupt(rec, rng) if rng.random() < bad_rate else json.dumps(rec)
        yield key, value


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default="config/config.yaml")
    ap.add_argument("--n", type=int, default=50_000)
    ap.add_argument("--rate", type=int, default=2000, help="records/second (0 = as fast as possible)")
    ap.add_argument("--fraud-rate", type=float, default=0.02)
    ap.add_argument("--bad-rate", type=float, default=0.0)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--to-dir", default=None, help="write JSONL files here instead of Kafka")
    ap.add_argument("--file-size", type=int, default=2000)
    args = ap.parse_args()
    cfg = load_config(args.config)

    if args.to_dir:
        out = Path(args.to_dir)
        out.mkdir(parents=True, exist_ok=True)
        buf, idx = [], 0
        for _, value in _records(args.n, args.fraud_rate, args.seed, args.bad_rate):
            buf.append(value)
            if len(buf) >= args.file_size:
                (out / f"batch_{int(time.time()*1000)}_{idx:05d}.jsonl").write_text("\n".join(buf))
                buf, idx = [], idx + 1
                if args.rate:
                    time.sleep(args.file_size / args.rate)
        if buf:
            (out / f"batch_{int(time.time()*1000)}_{idx:05d}.jsonl").write_text("\n".join(buf))
        print(f"wrote {args.n:,} records to {out}/")
        return

    from confluent_kafka import Producer  # imported lazily: optional dependency

    producer = Producer({"bootstrap.servers": cfg["kafka"]["bootstrap_servers"], "linger.ms": 20})
    topic = cfg["kafka"]["topic"]
    errors = []

    def on_delivery(err, _msg):
        if err is not None:
            errors.append(err)

    t0, sent = time.time(), 0
    for key, value in _records(args.n, args.fraud_rate, args.seed, args.bad_rate):
        producer.produce(topic, key=key, value=value, callback=on_delivery)
        sent += 1
        producer.poll(0)
        if args.rate and sent % args.rate == 0:
            time.sleep(max(0.0, 1.0 - ((time.time() - t0) % 1.0)))
    producer.flush()
    print(f"sent {sent:,} records to '{topic}' in {time.time()-t0:.1f}s ({len(errors)} delivery errors)")


if __name__ == "__main__":
    main()
