"""Transaction schema and categorical vocabularies shared by every component."""
from __future__ import annotations

CARD_TYPES = ["credit", "debit", "prepaid"]
PAYMENT_TYPES = ["upi", "card", "wallet", "bank_transfer", "netbanking"]
MERCHANT_CATEGORIES = [
    "grocery", "electronics", "travel", "dining", "fuel",
    "entertainment", "health", "utilities", "fashion", "other",
]

# name -> spark type name. ``is_fraud`` is optional (labels usually arrive late).
FIELDS = {
    "transaction_id": "string",
    "user_id": "string",
    "timestamp": "string",       # ISO-8601, parsed to event_time downstream
    "amount": "double",
    "merchant_id": "string",
    "merchant_category": "string",
    "payment_type": "string",
    "card_type": "string",
    "is_fraud": "integer",
}


def spark_schema():
    """Return the Spark StructType for incoming JSON transactions."""
    from pyspark.sql.types import DoubleType, IntegerType, StringType, StructField, StructType

    types = {"string": StringType(), "double": DoubleType(), "integer": IntegerType()}
    return StructType([StructField(n, types[t], True) for n, t in FIELDS.items()])
