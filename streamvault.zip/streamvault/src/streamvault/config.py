"""Configuration loading and lake path helpers."""
from __future__ import annotations

import copy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

import yaml

DEFAULTS: Dict[str, Any] = {
    "kafka": {"bootstrap_servers": "localhost:9092", "topic": "transactions", "partitions": 3},
    "lake": {
        "root": "data/lake",
        "spark_checkpoint_dir": "data/lake/_spark_checkpoint",
        "manifest_path": "data/lake/_recovery/manifest.jsonl",
    },
    "storage": {"s3": {"enabled": False}},
    "spark": {"master": "local[*]", "shuffle_partitions": 8},
    "streaming": {"trigger_seconds": 5, "max_offsets_per_trigger": 5000, "window": "5 minutes"},
    "adaptive_checkpoint": {
        "alpha": 0.40, "beta": 0.35, "gamma": 0.25, "theta": 0.65, "d_max": 8, "t_max": None,
    },
    "monitoring": {"prometheus_port": None},
}


def _merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(path: str | None = "config/config.yaml") -> dict:
    """Load YAML config on top of defaults. Missing file => defaults."""
    if path and Path(path).exists():
        with open(path, "r", encoding="utf-8") as fh:
            return _merge(DEFAULTS, yaml.safe_load(fh) or {})
    return copy.deepcopy(DEFAULTS)


@dataclass(frozen=True)
class LakePaths:
    """Medallion layer locations (Bronze / Silver / Gold) plus DLQ and alerts."""

    root: str

    @property
    def bronze(self) -> str:
        return f"{self.root}/bronze/transactions"

    @property
    def silver(self) -> str:
        return f"{self.root}/silver/transactions"

    @property
    def gold(self) -> str:
        return f"{self.root}/gold/merchant_aggregates"

    @property
    def dlq(self) -> str:
        return f"{self.root}/dlq/transactions"

    @property
    def alerts(self) -> str:
        return f"{self.root}/gold/fraud_alerts"

    def table(self, name: str) -> str:
        return {
            "bronze": self.bronze, "silver": self.silver, "gold": self.gold,
            "dlq": self.dlq, "alerts": self.alerts,
        }[name]


def lake_paths(cfg: dict) -> LakePaths:
    return LakePaths(cfg["lake"]["root"].rstrip("/"))
