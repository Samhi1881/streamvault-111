"""Optional Prometheus metrics (no-op if prometheus_client isn't installed)."""
from __future__ import annotations

import logging

log = logging.getLogger(__name__)

try:  # pragma: no cover - optional dependency
    from prometheus_client import Counter, Gauge, start_http_server
except ImportError:  # pragma: no cover
    Counter = Gauge = start_http_server = None


class Metrics:
    def __init__(self, port: int | None):
        self.enabled = bool(port) and Gauge is not None
        if not self.enabled:
            return
        self.batch_seconds = Gauge("streamvault_batch_seconds", "Micro-batch duration")
        self.batch_rows = Gauge("streamvault_batch_rows", "Rows in last micro-batch")
        self.score = Gauge("streamvault_checkpoint_score", "Adaptive checkpoint score S")
        self.lineage = Gauge("streamvault_lineage_depth", "Batches since last checkpoint")
        self.checkpoints = Counter("streamvault_checkpoints_total", "Checkpoints created")
        self.dlq_rows = Counter("streamvault_dlq_rows_total", "Records sent to the DLQ")
        start_http_server(port)
        log.info("Prometheus metrics on :%s/metrics", port)

    def observe_batch(self, seconds, rows, score, depth, checkpointed, dlq):
        if not self.enabled:
            return
        self.batch_seconds.set(seconds)
        self.batch_rows.set(rows)
        self.score.set(score)
        self.lineage.set(depth)
        self.dlq_rows.inc(dlq)
        if checkpointed:
            self.checkpoints.inc()
