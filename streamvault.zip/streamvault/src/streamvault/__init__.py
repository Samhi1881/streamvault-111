"""StreamVault: fault-tolerant, versioned data lake with adaptive checkpointing."""

__version__ = "0.1.0"
